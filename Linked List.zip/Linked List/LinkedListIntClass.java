import java.util.*;
public abstract class LinkedListIntClass implements LinkedListADT{
  
  //Class for a single node in linked list
  public class Node{
    public int info;
    public Node link;
    
    public Node(){
      info = 0;
      link = null;
    }
    public Node(int iInfo, Node iLink){
      info = iInfo;
      link = iLink;
    }
  }
  
  //Instance variables for LinkedListIntClass;
  protected Node first;
  protected Node last;
  protected int size;
  
  public LinkedListIntClass(){
    first = null;
    last = null;
    size = 0;
  }

  
  public boolean isEmptyList(){
    return size == 0;
  }
  
  public void initializeList(){
    first = null;
    last = null;
    size = 0;
  }
  
  public void print(){
    Node current;
    current = first;
    while(current!=null){
      System.out.print(current.info + " ");
      current = current.link;
    }
  }
  
  public int length(){
    return size;
  }
  
  public int front(){
    return first.info;
  }
  
  public int back(){
    return last.info;
  }
  
  
  
  
  
  
  public abstract boolean search(int searchItem);
  public abstract void insertFirst(int newItem);
  public abstract void insertLast(int newItem);
  public abstract void deleteNode(int deleteItem); 
}
