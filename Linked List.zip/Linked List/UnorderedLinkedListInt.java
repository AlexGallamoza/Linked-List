import java.util.*;
public class UnorderedLinkedListInt extends LinkedListIntClass{

  public UnorderedLinkedListInt() { 
    super();
  }
  
  public boolean search(int searchItem){
    Node current;
    current = first;
    while(current!=null){
      if(current.info == searchItem)
        return true;
      else
        current = current.link;
    }
    return false;
  }
  
  public void insertFirst(int newItem){
    Node newNode;
    newNode = new Node(newItem, first);
    first = newNode;
    if(last==null)
      last = newNode;
    size++;
  }
  
  public void insertLast(int newItem){
    Node newNode;
    newNode = new Node(newItem, null);
    if(first==null){
      first = newNode;
      last = newNode;
    }
    else{
      last.link = newNode;
      last = newNode;
    }
    size++;
  }
  
  public void deleteNode(int deleteItem){
    Node current;
    Node trailCurrent;
    boolean found;
    if(first == null)
      System.err.println("Cannot delete from an empty list.");
    else{
      if(first.info == deleteItem){
        first = first.link;
        if(first==null)
          last = null;
        size--;
      }
      else{
        found = false;
        trailCurrent = first;
        current = first.link;
        while(current!=null && !found){
          if(current.info == deleteItem)
            found = true;
          else{
            trailCurrent = current;
            current = current.link;
          }
        }
        if(found){
          size--;
          trailCurrent.link = current.link;
          if(last==current)
            last = trailCurrent;
        }
        else
          System.out.println("Item to be deleted is not in the list.");
      }
    }
  }
  
  public int findSum(){
    Node current = first;
    int sum = 0;
      while (current != null){
      sum += current.info;
      current = current.link;
    }
    return sum;
  }

  public int findMin(){
    Node current = first;
    int min = first.info;
    while(current != null){
      if(current.info < min)
        min = current.info;
      current = current.link;
    }
    return min;
  }
  
  public String toString(){
    Node current = first;
    String value = "";
    while(current!=null){
      if(current == first)
        value += current.info;
      else
        value += ", " + current.info;
      current = current.link;
    }
    return value;
  }
  
}



